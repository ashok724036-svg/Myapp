# 🚀 APK Banane ke Steps (GitHub Actions - FREE)

## Step 1 — gradle-wrapper.jar download karo (SIRF EK BAAR)

Yeh file sandbox mein download nahi ho sakti thi, isliye manually karo:

1. Is link pe jao:
   https://github.com/nicoulaj/gradle-wrapper-maven-plugin/raw/master/src/main/wrapper/gradle-wrapper.jar

   YA directly:
   https://raw.githubusercontent.com/gradle/gradle/v8.7.0/gradle/wrapper/gradle-wrapper.jar

2. Download ki hui `.jar` file ko project mein yahan rakho:
   ```
   NEETQuestSaver/gradle/wrapper/gradle-wrapper.jar
   ```

---

## Step 2 — GitHub pe upload karo

1. **github.com** pe jao → Sign up (free)
2. **New Repository** banao → naam: `NEETQuestSaver` → Public → Create
3. Apne computer pe terminal/Git Bash kholo:

```bash
cd NEETQuestSaver   # project folder mein jao
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TERA_USERNAME/NEETQuestSaver.git
git push -u origin main
```

---

## Step 3 — APK download karo

1. GitHub pe apna repo kholo
2. **Actions** tab click karo
3. **"Build Debug APK"** workflow click karo
4. Latest run click karo
5. Niche **Artifacts** section mein `NEETQuestSaver-debug-apk` download karo
6. ZIP extract karo → `app-debug.apk` milega

---

## Step 4 — Phone pe install karo

1. APK file apne phone pe transfer karo (USB / Google Drive / WhatsApp)
2. Phone Settings → **Security → Unknown Sources ON** karo
3. File manager se APK open karo → **Install**

---

## ⚡ Automatic Build

Har baar jab tum `git push` karoge, GitHub automatically naya APK build karega!
Actions tab mein jaake download kar lena.

---

## ❓ Agar GitHub Actions fail ho

Common fixes:
- `gradlew` file ko executable banao: `git update-index --chmod=+x gradlew`
- Phir: `git add . && git commit -m "fix gradlew permissions" && git push`
